import java.util.Scanner;

public class L8 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the value of n, a0, a1: ");
        int n = input.nextInt();
        int a0 = input.nextInt();
        int a1 = input.nextInt();

        int ak;

        System.out.println("The values of a0, a1, ..., an are:");
        System.out.println(a0);
        System.out.println(a1);

        for (int i = 2; i <= n; i++) {
            ak = (int) (Math.pow(i, 2) * (a1 - a0) + Math.pow(3, i));
            System.out.println(ak);
            a0 = a1;
            a1 = ak;
        }
    }
}

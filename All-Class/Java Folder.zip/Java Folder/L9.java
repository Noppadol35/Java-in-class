import java.util.Scanner;

public class L9 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the numbers: ");
        int num = input.nextInt();
        int max = num;
        int count = 0;

        while (num != 0) {
            if (num > max) {
                max = num;
                count = 1;
            } else if (num == max) {
                count++;
            }
            num = input.nextInt();
        }

        System.out.println("The largest number, count " + max + " "+count);
    }
}